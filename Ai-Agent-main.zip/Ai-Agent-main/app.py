import streamlit as st
import pandas as pd
import os
import json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# ──────────────── Page Config ────────────────
st.set_page_config(page_title="Abuzzz Store", layout="wide")

# ──────────────── Custom CSS ────────────────
st.markdown("""
<style>
  /* Page background */
  body, .main {
    background: linear-gradient(145deg, #1e1e2f, #2c3e50);
    color: #fff;
    font-family: 'Segoe UI', sans-serif;
  }
  /* Headers */
  h1, h2, h3 {
    background: linear-gradient(90deg, #f7971e, #ffd200);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    font-weight: bold;
  }
  /* Sidebar */
  .sidebar .sidebar-content {
    background-color: #1e1e2f;
    color: #fff;
    border-radius: 12px;
    padding: 15px;
  }
  /* Product Card */
  .product-card {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    border-radius: 15px;
    padding: 15px;
    margin: 20px 0;
    box-shadow: 0 6px 16px rgba(0,0,0,0.5);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    gap: 20px;
  }
  .product-card:hover {
    transform: scale(1.02);
    box-shadow: 0 12px 24px rgba(255,255,255,0.15);
  }
  /* Image */
  .product-img {
    border-radius: 10px;
    width: 110px;
    height: 110px;
    object-fit: cover;
    box-shadow: 0 4px 12px rgba(0,0,0,0.4);
  }
  /* Info */
  .product-name {
    font-size: 1.3rem;
    color: #ffea00;
    margin: 0;
  }
  .product-category {
    display: inline-block;
    background: #764ba2;
    color: #fff;
    font-size: 0.8rem;
    padding: 4px 10px;
    border-radius: 20px;
    margin-top: 6px;
  }
  .product-description {
    margin: 8px 0;
    color: #ccc;
    font-size: 0.95rem;
  }
  .product-price {
    font-weight: bold;
    color: #4caf50;
    font-size: 1rem;
  }
  /* Buttons */
  .stButton>button {
    background: linear-gradient(to right, #ff758c, #ff7eb3);
    color: white;
    padding: 10px 25px;
    border: none;
    border-radius: 30px;
    font-weight: 600;
    box-shadow: 0 4px 10px rgba(255,118,133,0.5);
    transition: all 0.3s ease-in-out;
  }
  .stButton>button:hover {
    background: linear-gradient(to right, #43e97b, #38f9d7);
    box-shadow: 0 6px 15px rgba(67,233,123,0.5);
  }
  /* Inputs */
  input, .stSelectbox>div>div, .stTextInput>div>input {
    background-color: #333 !important;
    color: #fff !important;
    border: 1px solid #666;
    border-radius: 8px;
  }
  /* Footer */
  footer {
    text-align: center;
    color: #888;
    font-size: 0.85rem;
    padding: 20px 0;
    border-top: 1px solid #444;
  }
</style>
""", unsafe_allow_html=True)

# ──────────────── Data & Recommendations ────────────────
df = pd.read_csv("products.csv")
users_file = "users.json"
if not os.path.exists(users_file):
    json.dump({}, open(users_file, "w"))

# TF-IDF matrix
tfidf = TfidfVectorizer(stop_words='english')
df['combined'] = (df['category'] + " " + df['description']).fillna('')

tfidf_matrix = tfidf.fit_transform(df['combined'])
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# Session init
for key in ['cart','user','history','bought','checkout']:
    if key not in st.session_state:
        st.session_state[key] = [] if key in ['cart','history'] else False if key in ['bought','checkout'] else None

# Auth
def login(u):
    st.session_state.user = u
    users = json.load(open(users_file))
    if u not in users:
        users[u] = {"history":[]}
        json.dump(users, open(users_file,"w"))

def save_history(pid):
    if st.session_state.user:
        users = json.load(open(users_file))
        if pid not in users[st.session_state.user]["history"]:
            users[st.session_state.user]["history"].append(pid)
            json.dump(users, open(users_file,"w"))

# Safe image loader
def safe_image(p,w=150):
    if os.path.exists(p): st.image(p,width=w)
    else: st.image("https://via.placeholder.com/150",width=w)

# ──────────────── UI Layout ────────────────
st.title("🛍️ Abuzzz Store")

# Sidebar: Login
with st.sidebar:
    st.header("🔐 Login")
    u = st.text_input("Username", key="u_in")
    if st.button("Login"):
        if u.strip(): login(u.strip()); st.success(f"Welcome, {u}!")
        else: st.warning("Enter a valid username")

# Sidebar: Cart
st.sidebar.header("🛒 Cart")
total=0; new=[]
for i,it in enumerate(st.session_state.cart):
    st.sidebar.write(f"• {it['product_name']} — ${it['price']:.2f}")
    total+=it['price']
    if st.sidebar.button(f"❌ Remove {it['product_name']}",key=f"r{i}"): continue
    new.append(it)
st.session_state.cart=new
st.sidebar.markdown(f"**Total: ${total:.2f}**")

# Checkout
if st.session_state.cart:
    if not st.session_state.bought:
        if st.sidebar.button("🛒 Buy Now"): st.session_state.bought=True
    elif not st.session_state.checkout:
        if st.sidebar.button("💳 Proceed to Checkout"): st.session_state.checkout=True
    else:
        st.sidebar.success("🎉 Thank you for your order!")
        st.session_state.cart=[]; st.session_state.bought=False; st.session_state.checkout=False
        st.rerun()

# Trending
st.subheader("🔥 Trending Now")
t3 = df.sort_values(by='price',ascending=False).head(3)
c=st.columns(3)
for j,(_,r) in enumerate(t3.iterrows()):
    with c[j]:
        st.markdown('<div class="product-card">',unsafe_allow_html=True)
        safe_image(r['image'],140)
        st.markdown(f"<div class='product-name'>{r['product_name']}</div>",unsafe_allow_html=True)
        st.markdown(f"<div class='product-price'>${r['price']:.2f}</div>",unsafe_allow_html=True)
        st.markdown("</div>",unsafe_allow_html=True)
st.markdown("---")

# Browse + Filters
st.subheader("🔍 Browse Products")
q = st.text_input("Search")
pr = st.slider("Price Range",0,int(df['price'].max()),(0,int(df['price'].max())))
cat = st.selectbox("Category",["All"]+df['category'].unique().tolist())

f = df[df['price'].between(pr[0],pr[1])]
if cat!="All": f=f[f['category']==cat]
if q: f=f[f['product_name'].str.contains(q,case=False)|f['description'].str.contains(q,case=False)]

# Pagination
ps=6; tp=(len(f)+ps-1)//ps; p=st.number_input("Page",1,tp,1)
page=f.iloc[(p-1)*ps:p*ps]

# Products grid
for _,r in page.iterrows():
    st.markdown('<div class="product-card">',unsafe_allow_html=True)
    col1,col2=st.columns([1,3])
    with col1: safe_image(r['image'],100)
    with col2:
        st.markdown(f"<div class='product-name'>{r['product_name']}</div>",unsafe_allow_html=True)
        st.markdown(f"<div class='product-price'>${r['price']:.2f}</div>",unsafe_allow_html=True)
        st.markdown(f"<div class='product-desc'>{r['description']}</div>",unsafe_allow_html=True)
        if st.button(f"➕ Add to Cart",key=f"a{r['product_id']}"):
            st.session_state.cart.append(r.to_dict()); save_history(r['product_id'])
            st.success(f"{r['product_name']} added to cart")
    st.markdown("</div>",unsafe_allow_html=True)

# Recommendation logic
def rec_hist():
    if not st.session_state.user: return []
    us=json.load(open(users_file)); h=us[st.session_state.user]["history"]
    if not h: return []
    idxs=[df.index[df['product_id']==pid][0] for pid in h if pid in df['product_id'].values]
    sc=sum(cosine_sim[i] for i in idxs)/len(idxs)
    sims=sorted(enumerate(sc),key=lambda x:x[1],reverse=True)
    return [df.iloc[i] for i,_ in sims if df.iloc[i]['product_id'] not in h][:3]

def rec_prod(pid):
    if pid not in df['product_id'].values: return []
    i=df.index[df['product_id']==pid][0]
    sims=sorted(enumerate(cosine_sim[i]),key=lambda x:x[1],reverse=True)
    return [df.iloc[i] for i,_ in sims if df.iloc[i]['product_id']!=pid][:3]

# History-based
if st.session_state.user:
    st.markdown("---"); st.subheader("🔁 For You (History)")
    rh=rec_hist()
    cc=st.columns(3)
    for j,r in enumerate(rh):
        with cc[j]:
            st.markdown('<div class="product-card">',unsafe_allow_html=True)
            safe_image(r['image'],140)
            st.markdown(f"<div class='product-name'>{r['product_name']}</div>",unsafe_allow_html=True)
            st.markdown("</div>",unsafe_allow_html=True)

# Fresh picks
if st.session_state.cart:
    last=st.session_state.cart[-1]
    st.markdown("---"); st.subheader("✨ Fresh Picks")
    rp=rec_prod(last['product_id'])
    cc=st.columns(3)
    for j,r in enumerate(rp):
        with cc[j]:
            st.markdown('<div class="product-card">',unsafe_allow_html=True)
            safe_image(r['image'],140)
            st.markdown(f"<div class='product-name'>{r['product_name']}</div>",unsafe_allow_html=True)
            st.markdown("</div>",unsafe_allow_html=True)

# Footer
st.markdown("---")
st.markdown("<footer>Made by  D5 Team · © 2025</footer>", unsafe_allow_html=True)
